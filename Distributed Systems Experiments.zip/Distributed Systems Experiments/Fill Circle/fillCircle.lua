-------------------------------------------------
-------------------------------------------------
--				FILLCIRCLE ALGORITHM
-------------------------------------------------
-------------------------------------------------

state = {}
debugMode = true
nStep = 0

function init()
	robot.colored_blob_omnidirectional_camera.enable() 
	nextState = "fillCircleState"
end

function step()
	nStep = nStep + 1
	state[nextState]()
end

function reset()
	nextState = "fillCircleState"
end

function destroy()
   -- destroy
end

------------------------------
-- STATE: FILL CIRCLE
------------------------------
function state.fillCircleState()
	D = 150
	k = 1
	w = -1
	d = farthestRobotDistance()

	if d > D then 
		robot.leds.set_single_color(13, "red")
		speedFromForce(farthestRobotForce(k))
	end
        
	if d <= D then 
		robot.leds.set_single_color(13,  "green")
		speedFromForce(nearestRobotForce(w))
	end    

	nextState="fillCircleState"  
end

-------------------------------------------------
--	GENERAL FUNCTIONS
-------------------------------------------------

--------------------------------
-- FARTHEST ROBOT DISTANCE
----------------------------------
function farthestRobotDistance()
	farthestDistance = -math.huge

	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if farthestDistance < distance then farthestDistance = distance end
	end

	return farthestDistance
end

--------------------------------
-- FARTHEST ROBOT DISTANCE FORCE
--------------------------------
function farthestRobotForce(k)
	farthestDistance = -math.huge
	angle = 0

	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if farthestDistance < distance then 
			farthestDistance = distance
			angle = robot.colored_blob_omnidirectional_camera[i].angle
		end
	end

	return { x = k * math.cos(angle), y =  k * math.sin(angle) }
end

--------------------------------
-- NEAREST ROBOT DISTANCE FORCE
--------------------------------
function nearestRobotForce(k)
	nearestDistance = math.huge
	angle = 0

	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if nearestDistance > distance then 
			nearestDistance = distance
			angle = robot.colored_blob_omnidirectional_camera[i].angle
		end
	end

	return { x = k * math.cos(angle), y =  k * math.sin(angle) }
end

-------------------------------------------------
--	UTILITY FUNCTIONS
-------------------------------------------------

------------------------------
-- SPEED FROM FORCE     
------------------------------
function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 5

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
if(robot.id == "fb1") then
    if(debugMode == true) then
        log(string)
    end
end
end
