-- Global variables here
state = {}
debugMode = true
nStep = 0
A_PARAM = 0.008
T_LEAVE = 150
TIMER_LEAVE = 0

function init()
    nextState = "randomWalkState"
    robot.colored_blob_omnidirectional_camera.enable()
    
end


function step()
    nStep = nStep + 1
    state[nextState]()
end


function reset()
    nextState = "randomWalkState"  
end

function destroy()
   -- destroy
end




------------------------------
-- STATE: RANDOM WALK
------------------------------

function state.randomWalkState()
    robot.leds.set_single_color(13,  "blue")
    nextState="randomWalkState"
    if TIMER_LEAVE > T_LEAVE then
		  
        if robotDetected() == true then
            nextState="waitState"
        end
    end
    
    TIMER_LEAVE = TIMER_LEAVE + 1
    speedFromForce(sumUp({randomForce(10), linearForce(3), obstacleAvoidanceForce(8,0)}))
    
end


------------------------------
-- STATE: WAIT
------------------------------
function state.waitState()
    robot.leds.set_single_color(13,  "red")
   -- speedFromForce(sumUp({minForceCluster(), obstacleAvoidanceForce(10,0)}))
      speedFromForce(sumUp({socialForce(), obstacleAvoidanceForce(1,0)}))
    if not robotDetected() or (pLeave() > robot.random.uniform()) then
		 -- myLog(pLeave())
		  TIMER_LEAVE = 0
        nextState="randomWalkState"
    else
        nextState="waitState"  
    end
end






-------------------------------------------------
--  GENERAL FUNCTIONS
-------------------------------------------------
function socialForce()
	C1 = 40.0
	C2 = 1.0
	S1 = 2.0
	S2 = 1.0

	force = { x = 0, y = 0}
	w = 200

	for i = 1, #robot.colored_blob_omnidirectional_camera do
		r = robot.colored_blob_omnidirectional_camera[i].distance
		angle = robot.colored_blob_omnidirectional_camera[i].angle

		f = (-C1/math.pow(r, S1)) +  (C2/math.pow(r, S2))

		force.x = force.x + f * math.cos(angle)
      force.y = force.y + f * math.sin(angle)
   end
			
	force.x = force.x * w
   force.y = force.y * w

  return  force	
end



-------------------------------------------------
--  UTILITY FUNCTIONS
-------------------------------------------------

--------------------------
-- P LEAVE      --
--------------------------
function pLeave()
    nRobots = #robot.colored_blob_omnidirectional_camera
    return A_PARAM / (1 + nRobots * nRobots)
end

--------------------------
-- ROBOT DETECTED      --
--------------------------
function robotDetected()
    if #robot.colored_blob_omnidirectional_camera > 0 then
        return true
    end
    
    return false
end

--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function fieldForce(k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
    end

    return colorForce
end


------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
if(robot.id == "fb1") then
    if(debugMode == true) then
        log(string)
    end
end
end

------------------------------
-- SPEED FROM FORCE     
------------------------------

function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 0.3

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

--------------------------------
-- VECTOR SUM FORCES    
--------------------------------

function sumUp(forces)
    sumForce = { x=0, y=0}
    for i = 1, #forces do
        sumForce.x = sumForce.x + forces[i].x
        sumForce.y = sumForce.y + forces[i].y
    end
    return sumForce
end

-------------------------------
-- RANDOM FORCE              
-------------------------------

function randomForce(val)
    angle = robot.random.uniform(- math.pi/2, math.pi/2)
   rndForce = {x = val * math.cos(angle), y = val * math.sin(angle) }

    return rndForce
end


-------------------------------
-- LINEAR FORCE 
-------------------------------

function linearForce(k)
     if(k == nil) then
        k=10
     end
    lForce = { x=k, y=0}
    return lForce
end

-------------------------------
-- OBSTACLE AVOIDANCE
-------------------------------


function obstacleAvoidanceForce(k,d)
    if(k == nil) then
        k=20
    end
    if(d == nil) then
        d=0.6
     end
   avoidanceForce = {x = 0, y = 0}
   for i = 1,24 do
        -- "-100" for a strong repulsion 
        v = -k * robot.proximity[i].value 
        a = robot.proximity[i].angle 

        sensorForce = {x = v * math.cos(a), y = 2 * v * math.sin(a)}
        avoidanceForce.x = avoidanceForce.x + sensorForce.x
        avoidanceForce.y = avoidanceForce.y + sensorForce.y
   end

    return avoidanceForce
end

----------------------------------------------------------
-- SENSOR COLOR: get  color more safely                 --
----------------------------------------------------------
function getColor(sensor)
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "white"
    end
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 0) then
        return "red"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "green"
    end
    if(sensor.color.red == 0 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "blue"
    end
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "yellow"
    end 
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "purple"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "cyano"
    end
    if(sensor.color.red == 160 and sensor.color.green == 32 and sensor.color.blue == 240) then
        return "darkPurple"
    end
end



--print into Log a table
function tprint (tbl)
  for k, v in pairs(tbl) do
    if type(v) == "table" then
      tprint(v)
    elseif type(v) == 'boolean' then
      myLog(tostring(v))      
    else
      myLog(v)
    end
  end
end

