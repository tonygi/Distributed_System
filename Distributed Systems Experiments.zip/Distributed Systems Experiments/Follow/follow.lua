-- Global variables here
state = {}
debugMode = true
nStep = 0
LEFT = { dist = 0, angle = 0 }
RIGHT= { dist = 0, angle = 0 }
TO_FOLLOW = { dist = 0, angle = 0 }
precD = 0
function init()
     robot.leds.set_single_color(13, "green")


    if robot.id == "fb0" or robot.id == "fb6"then
        nextState = "leaderState"
    else
      nextState = "leftRightState"
    end
    robot.colored_blob_omnidirectional_camera.enable()
  
end


function step()
    nStep = nStep + 1
    state[nextState]()
end


function reset()
robot.leds.set_single_color(13, "green")
    if robot.id == "fb0" or robot.id == "fb6" then
        nextState = "leaderState"
    else 
        nextState = "leftRightState"
    end

   
     
end

function destroy()
   -- destroy
end
---------------------
-- STATE: leftRight
---------------------

function state.leaderState() 
    if nStep > 100 then
        robot.leds.set_single_color(13, "red")   
          speedFromForce(sumUp({randomForce(1), linearForce(1), obstacleAvoidanceForce(6,0)}))
    end  
    
   nextState = "leaderState"
end

function state.leftRightState() 
    --if nStep > 5 then
        getLeftRight()
   -- end
   nextState = "motionDetectionState"
end


function state.motionDetectionState()

     myLog("LEFT " ..LEFT.dist)
     myLog("RIGHT "..RIGHT.dist)
    if motionDetection(RIGHT) == true then
            robot.leds.set_single_color(13, "blue") 
        nextState = "followingState"
        TO_FOLLOW = RIGHT    
    elseif  motionDetection(LEFT) == true then
            robot.leds.set_single_color(13, "blue") 

        nextState = "followingState"
        TO_FOLLOW = LEFT  
    else
        nextState = "motionDetectionState"
    end
end

function state.followingState()
     
    k=7
    force = {x=0, y=0}
    d = TO_FOLLOW.dist
    TO_FOLLOW = getLeader(TO_FOLLOW)
    
    if d < TO_FOLLOW.dist then
        force = { x = k * math.cos(TO_FOLLOW.angle), y = k * math.sin(TO_FOLLOW.angle) }
    end
    if TO_FOLLOW.dist == 0 or precD == d then
		  speedFromForce(force)
	 else
    speedFromForce(sumUp({force,obstacleAvoidanceForce(1,0)}))
	 end
	 precD = d
    nextState = "followingState"
end

-------------------------------------------------
--  UTILITY FUNCTIONS
-------------------------------------------------

function getLeftRight()
   minDistance2 = 999999
   minDistance  = 999999
   minAngle  = 0
   minAngle2 = 0 
   for i = 1, #robot.colored_blob_omnidirectional_camera do
       distance = robot.colored_blob_omnidirectional_camera[i].distance
       if distance < minDistance then
          minDistance2 = minDistance
          minDistance = distance
          minAngle = robot.colored_blob_omnidirectional_camera[i].angle
       elseif distance < minDistance2 then
          minDistance2 = distance
          minAngle2 = robot.colored_blob_omnidirectional_camera[i].angle
       end
   end
    myLog("MinDistance "..minDistance)
    myLog("MinDistance2 "..minDistance2)
   LEFT.dist  = minDistance  LEFT.angle  = minAngle
   RIGHT.dist = minDistance2 RIGHT.angle = minAngle2
    
    
end

function motionDetection(ANG)
    epsilon = 2
    minDistance  = 999999
    minAngle  = 0

    if  #robot.colored_blob_omnidirectional_camera == 0 then
        return false
    end 
    for i = 1, #robot.colored_blob_omnidirectional_camera do
        distance = robot.colored_blob_omnidirectional_camera[i].distance
        angle = robot.colored_blob_omnidirectional_camera[i].angle
          anglediff = (math.deg(ANG.angle) - math.deg(angle) + 180 + 360) % 360 - 180
          if (anglediff <= 45 and anglediff>=-45) then

                if minDistance  == 999999 then
                     myLog("OK SONO ENTRATO")
                 end
            if distance < minDistance then
              minDistance = distance
              minAngle = angle
                  myLog("OK SONO ENTRATO2")
            end
        end
    end

   -- if minDistance  == 999999 then
   --     myLog("CRASH ON MINDISTANCE")
  --  end
    
    if math.abs(ANG.dist - minDistance) > epsilon then
        return true
    end
    
    return false
end


function getLeader(leader)
    minDistance  = 999999
    minAngle  = 0
    for i = 1, #robot.colored_blob_omnidirectional_camera do
        distance = robot.colored_blob_omnidirectional_camera[i].distance
        angle = robot.colored_blob_omnidirectional_camera[i].angle
        anglediff = (math.deg(leader.angle) - math.deg(angle) + 180 + 360) % 360 - 180
          if (anglediff <= 45 and anglediff>=-45) then
            if distance < minDistance then
              minDistance = distance
              minAngle = angle
            end
        end
    end
	 if minDistance == 999999 then minDistance = 0 end
    ret = {dist = minDistance, angle = minAngle}
    return ret

end
--------------------------
-- ROBOT ID             --
--------------------------
function idNumber()
    robotId = string.gsub(robot.id, "fb", "")
    id = tonumber(robotId)

    return id   
end

--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function colorFieldForce(color, k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if(getColor(robot.colored_blob_omnidirectional_camera[i]) == color) then
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
        end
    end

    return colorForce
end



----------------------------------------------------------
-- SENSOR COLOR: get  color more safely                 --
----------------------------------------------------------
function getColor(sensor)
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "white"
    end
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 0) then
        return "red"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "green"
    end
    if(sensor.color.red == 0 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "blue"
    end
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "yellow"
    end 
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "purple"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "cyano"
    end
    if(sensor.color.red == 160 and sensor.color.green == 32 and sensor.color.blue == 240) then
        return "darkPurple"
    end
end


--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function fieldForce(k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
    end

    return colorForce
end


------------------------------
-- ANGLE ORIENTATION 
------------------------------
function getAngle()
    PI=math.pi
    angle = robot.positioning.orientation.angle*robot.positioning.orientation.axis.z
   if angle<-PI then angle = angle+2*PI end
   if angle >PI then angle = angle-2*PI end
   return angle
end

------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
     if robot.id =="fb7" then
        if(debugMode == true) then
        log(string)
        end
    end
end

------------------------------
-- SPEED FROM FORCE     
------------------------------

function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 0.3

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

--------------------------------
-- VECTOR SUM FORCES    
--------------------------------

function sumUp(forces)
    sumForce = { x=0, y=0}
    for i = 1, #forces do
        sumForce.x = sumForce.x + forces[i].x
        sumForce.y = sumForce.y + forces[i].y
    end
    return sumForce
end

-------------------------------
-- RANDOM FORCE              
-------------------------------

function randomForce(val)
    angle = robot.random.uniform(- math.pi/2, math.pi/2)
   rndForce = {x = val * math.cos(angle), y = val * math.sin(angle) }

    return rndForce
end

-------------------------------
-- neighbourForce             
-------------------------------

function neighbourForce(val, angle)
     force = {x = val * math.cos(angle), y = val * math.sin(angle) }
     return force
end

-------------------------------
-- LINEAR FORCE 
-------------------------------

function linearForce(k)
     if(k == nil) then
        k=10
     end
    lForce = { x=k, y=0}
    return lForce
end

-------------------------------
-- OBSTACLE AVOIDANCE
-------------------------------


function obstacleAvoidanceForce(k,d)
    if(k == nil) then
        k=20
    end
    if(d == nil) then
        d=0.6
     end
   avoidanceForce = {x = 0, y = 0}
   for i = 1,24 do
        -- "-100" for a strong repulsion 
        v = -k * robot.proximity[i].value 
        a = robot.proximity[i].angle 

        sensorForce = {x = v * math.cos(a), y = 2 * v * math.sin(a)}
        avoidanceForce.x = avoidanceForce.x + sensorForce.x
        avoidanceForce.y = avoidanceForce.y + sensorForce.y
   end

    return avoidanceForce
end

function radToAngle(rad)
    ret = (rad * 180 / math.pi)
    if ret < 0 then
        ret = ret * -1
    end
    return ret
end

function checkAngle(ang)
    if ang < 0 then 
        return (360 - math.abs(ang))
    elseif ang > 360 then
        return (ang - 360)
    else
        return ang
    end
end

--print into Log a table
function tprint (tbl)
  for k, v in pairs(tbl) do
    if type(v) == "table" then
      tprint(v)
    elseif type(v) == 'boolean' then
      myLog(tostring(v))      
    else
      myLog(v)
    end
  end
end
