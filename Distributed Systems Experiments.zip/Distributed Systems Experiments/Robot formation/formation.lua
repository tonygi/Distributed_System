-- Global variables here
state = {}
debugMode = true
desiredDistance = 50
nStep = 0
averageHeading = 0
threshold = 30
precDistance = math.huge
probCluster = 0.10

function init()
	--myLog(tableToAngle(angleToTable(1.0302100)))
	
	nextState = "dispersionState"
	robot.leds.set_single_color(13,  "green")
	if(robot.id == "fb12222222") then
		robot.leds.set_single_color(13,  "red")
		nextState = "specialState"
	end


	robot.colored_blob_omnidirectional_camera.enable() 
end


function step()
	
	nStep = nStep + 1
  -- if robot.id == "fb12" or robot.id == "fb13" or robot.id == "fb2"and nStep >= 1000 then
	--	nextState="deadState"
--	end
	state[nextState]()
end


function reset()
	nextState = "dispersionState"

	robot.leds.set_single_color(13,  "green")
	if(robot.id == "fb1222") then
		robot.leds.set_single_color(13,  "red")
		nextState = "specialState"
	end
end

function destroy()
   -- destroy
end

------------------------------
-- STATE: dispersion
------------------------------

function state.dispersionState()
	robot.leds.set_single_color(13,  "red")			
	neighbours = getNeighbours()
	if(neighbours == 1) then
		speedFromForce(sumUp({neighbourForce(1,robot.colored_blob_omnidirectional_camera[1].angle), linearForce(3), obstacleAvoidanceForce()}))

	--elseif(neighbours >= 2) then
	--mantieni la strada che stavi gia' percorrendo

	else
	-- Let's have a random walk!
		speedFromForce(sumUp({randomForce(1), linearForce(3), obstacleAvoidanceForce()}))
	end
		
	if getNeighbours() >= 2 then
		nextState="positioningState" 
	else
		nextState="dispersionState"
	end
	
end


------------------------------
-- STATE: positioning
------------------------------

function state.positioningState()
	
	robot.leds.set_single_color(13,  "blue")
	tollerance = 10
	--tprint(angleToTable(1.5678),0)
	K = 150
	totalForce = {x=0, y=0}

	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		angle = robot.colored_blob_omnidirectional_camera[i].angle
		
		if distance < desiredDistance then
			distance = -1 * distance
		end 
		
		if distance < 1.3 * desiredDistance then
			totalForce.x = totalForce.x + K/distance * math.cos(angle)
  			totalForce.y = totalForce.y + (K+10)/distance * math.sin(angle)
		end
	end

	speedFromForce(totalForce)

	
	goAlign = 1
	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if distance < (1.3 * desiredDistance) then
			if not (desiredDistance - tollerance < distance and desiredDistance + tollerance > distance) then
				goAlign = 0
				break
			end
		end
	end

	
	
	robot.range_and_bearing.set_data(angleToTable(getAngle()))
	averageHeading = neighboursAVG()
	
	if getNeighbours() > 1 and goAlign == 0 then
		nextState="positioningState" 
	elseif getNeighbours() > 1 and goAlign == 1 then
		nextState="alignmentState"
	else
		nextState="dispersionState"
	end

		avgNeighbours = getNeighboursAvgDistance()
	if avgNeighbours < threshold then
		if precDistance < avgNeighbours then
			probCluster = probCluster - 0.20
		end
		probCluster = probCluster + 0.10
		myLog("Sono in cluster")
		--check clustering state
		--math.randomseed(os.time())
		rnd = math.random()
			if rnd <= probCluster then
				--random walk
				speedFromForce(sumUp({randomForce(1), linearForce(3), obstacleAvoidanceForce()}))
			end
			precDistance = avgNeighbours
			nextState="dispersionState"
	end
   

end

function state.deadState()
   totalForce = {x=0, y=0}
   speedFromForce(totalForce)
   --robot.leds.set_single_color(13,  "black")
	nextState= "deadState"
end

function state.specialState()
	totalForce = {x=0, y=1}

	
	--myLog(getAngle())
	speedFromForce(totalForce)
end





------------------------------
-- STATE: alignment
------------------------------

function state.alignmentState()

	tollerance = 15

	tolleranceH = 0.4
	robot.leds.set_single_color(13,  "green")

	
	K3 = 40
	totalForce = {x = 0, y = (averageHeading - getAngle()) * K3}

	goMoving = 0

	
	if math.abs(getAngle() - averageHeading) < tolleranceH then
		goMoving = 1
	end
	
	speedFromForce(totalForce)

	
	
	goPosition = 1
	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if distance < (1.3 * desiredDistance) then

			if not((desiredDistance - tollerance) > distance or (desiredDistance + tollerance) < distance) then
				goPosition = 0
				break
			end
		end
	end

	

	if goPosition == 1 then
		nextState="positioningState"
	elseif getNeighbours() > 1 and goMoving == 1 then
		nextState="movingState"
	elseif getNeighbours() > 1 and goPosition == 0 then
		nextState="alignmentState" 

	end
end

------------------------------
-- STATE: moving
------------------------------

function state.movingState()
	
	robot.leds.set_single_color(13,  "yellow")

   robot.range_and_bearing.set_data(angleToTable(getAngle()))
	averageHeading = neighboursAVG()

	tollerance = 30
	tolleranceH = 0.9
	K = 100
	totalForce = {x=10, y=0}

	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		angle = robot.colored_blob_omnidirectional_camera[i].angle
		
		if distance < desiredDistance then
			distance = -1 * distance
		end 
		
		if distance < 1.3 * desiredDistance then
			totalForce.x = totalForce.x + K/distance * math.cos(angle)
  			totalForce.y = totalForce.y + (K+10)/distance * math.sin(angle)
		end
	end


	goAlignment = 0

	if math.abs(getAngle() - averageHeading) > tolleranceH then
		goAlignment = 1
	end
	speedFromForce(totalForce)

	goPosition = 1
	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if distance < (1.3 * desiredDistance) then

			if (desiredDistance - tollerance > distance) or (desiredDistance + tollerance < distance) then
				goPosition = 0
				--nextState="positioningState"
				--return 0
			end
		end
	end

	
	if getNeighbours() > 1 and goPosition == 1 then
		nextState="positioningState"
	elseif goAlignment == 1 then
		nextState="alignmentState"
	elseif getNeighbours() > 1 and goPosition == 0 then
		nextState="movingState" 
	end
end


-------------------------------------------------
--	GENERAL FUNCTIONS
-------------------------------------------------

function neighboursAVG()
  numRobots=0
  sumAngle = 0
  avg = 0
  for i = 1, #robot.range_and_bearing do -- for each robot seen 
    	 if robot.range_and_bearing[i].range < (1.3 * desiredDistance) then    				
      	 	 sumAngle = sumAngle + tableToAngle(robot.range_and_bearing[i].data) 
     		 numRobots =  numRobots+1
       end
	end
		if(sumAngle > 0) then
   		avg = sumAngle / numRobots
		end
   return avg
end


------------------------------
-- NUMBER OF NEIGHBOURS
------------------------------
function getNeighbours()
	neighbours = 0
	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if distance < (1.3 * desiredDistance) then
			neighbours = neighbours + 1
		end
	end
 	return neighbours
end

------------------------------
-- ANGLE TO TABLE
------------------------------
function angleToTable(angle)
	decimalValue = angle
	cifre={}
	for i = 1, 10 do 
		if( math.floor(decimalValue) > 0) then	
			tmp = decimalValue % 10
			cifre[i] = math.floor(tmp)
			decimalValue = decimalValue * 10
		else
			cifre[i] = 0
		end
	end
	
	return cifre
end

------------------------------
-- TABLE TO ANGLE
------------------------------
function tableToAngle(table)
	angle = 0
		for k, v in pairs(table) do
			angle = angle + (v / (math.pow(10,k-1)))
		end
	return angle
end

------------------------------
-- getNeighboursAvgDistance
------------------------------
function getNeighboursAvgDistance()
	neighboursDistance = 0.0
	neighbours = 0.0
	for i = 1, #robot.colored_blob_omnidirectional_camera do
		distance = robot.colored_blob_omnidirectional_camera[i].distance
		if distance < (1.3 * desiredDistance) then
			neighboursDistance = neighboursDistance + distance
			neighbours = neighbours + 1
		end
	end
	avg = neighboursDistance / neighbours
 	return avg
end


-------------------------------------------------
--	UTILITY FUNCTIONS
-------------------------------------------------

------------------------------
-- ANGLE ORIENTATION 
------------------------------
function getAngle()
	PI=math.pi
	angle = robot.positioning.orientation.angle*robot.positioning.orientation.axis.z
   if angle<-PI then angle = angle+2*PI end
   if angle >PI then angle = angle-2*PI end
   return angle
end

------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
if(robot.id == "fb1") then
    if(debugMode == true) then
        log(string)
    end
end
end

------------------------------
-- SPEED FROM FORCE     
------------------------------

function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 0.3

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

--------------------------------
-- VECTOR SUM FORCES    
--------------------------------

function sumUp(forces)
    sumForce = { x=0, y=0}
    for i = 1, #forces do
        sumForce.x = sumForce.x + forces[i].x
        sumForce.y = sumForce.y + forces[i].y
    end
    return sumForce
end

-------------------------------
-- RANDOM FORCE              
-------------------------------

function randomForce(val)
	angle = robot.random.uniform(- math.pi/2, math.pi/2)
   rndForce = {x = val * math.cos(angle), y = val * math.sin(angle) }

	return rndForce
end

-------------------------------
-- neighbourForce             
-------------------------------

function neighbourForce(val, angle)
	 force = {x = val * math.cos(angle), y = val * math.sin(angle) }
	 return force
end

-------------------------------
-- LINEAR FORCE 
-------------------------------

function linearForce(k)
	 if(k == nil) then
		k=10
	 end
	lForce = { x=k, y=0}
	return lForce
end

-------------------------------
-- OBSTACLE AVOIDANCE
-------------------------------


function obstacleAvoidanceForce(k,d)
	if(k == nil) then
		k=20
	end
	if(d == nil) then
		d=0.6
	 end
   avoidanceForce = {x = 0, y = 0}
   for i = 1,24 do
        -- "-100" for a strong repulsion 
        v = -k * robot.proximity[i].value 
        a = robot.proximity[i].angle 

        sensorForce = {x = v * math.cos(a), y = 2 * v * math.sin(a)}
        avoidanceForce.x = avoidanceForce.x + sensorForce.x
        avoidanceForce.y = avoidanceForce.y + sensorForce.y
   end

    return avoidanceForce
end


--------------------------------
-- SENSOR COLOR
----------------------------------
function getColor(sensor)
	if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 255) then
		return "white"
	end
	if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 0) then
		return "red"
	end
	if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 0) then
		return "green"
	end
	if(sensor.color.red == 0 and sensor.color.green == 0 and sensor.color.blue == 255) then
		return "blue"
	end
	if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 0) then
		return "yellow"
	end	
	if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 255) then
		return "purple"
	end
	if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 255) then
		return "cyano"
	end
	if(sensor.color.red == 160 and sensor.color.green == 32 and sensor.color.blue == 240) then
		return "darkPurple"
	end
end

--print into Log a table
function tprint (tbl)
  for k, v in pairs(tbl) do
    if type(v) == "table" then
      tprint(v)
    elseif type(v) == 'boolean' then
      myLog(tostring(v))      
    else
      myLog(v)
    end
  end
end
