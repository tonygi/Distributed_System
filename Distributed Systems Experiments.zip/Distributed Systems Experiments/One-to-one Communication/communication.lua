-- Global variables here
state = {}
debugMode = true
nStep = 0
Trandom = 0
TARGET = {}
timer = 0
TAU = 25
myColor = ""

function init()
    
    nextState = "wheelAckState"
   
    robot.colored_blob_omnidirectional_camera.enable()
    if robot.id == "fb0" then
        nextState = "sosState"
    end

end


function step()
    nStep = nStep + 1
    state[nextState]()
end


function reset()
   
    nextState = "wheelAckState"
    if robot.id == "fb0" then
        nextState = "sosState"
    end
end

function destroy()
   -- destroy
end



------------------------------
-- STATE: SOS
------------------------------

function state.sosState()
    
    robot.leds.set_single_color(13, "red")
    
    TARGET = targetSelection()
    
    if getTargetColor(TARGET) == "blue" then
        nextState = "spState"
    else
        nextState = "sosState"
    end
    
end



------------------------------
-- STATE: SP
------------------------------

function state.spState()
    
	 targetColor = getTargetColor(TARGET)
    
    if targetColor ~= "white" then 
    	robot.leds.set_single_color(13, targetColor)
    
   	 if  #robot.colored_blob_omnidirectional_camera == 1 and targetColor ~= "white" then
        nextState = "ceState"
    	else
        nextState = "spState"
    	end
	
	 else
		nextState = "spState"
	 end
	 
end


------------------------------
-- STATE: CE
------------------------------

function state.ceState()
    robot.leds.set_single_color(13, "red")
    nextState = "ceState"
end



------------------------------
-- STATE: WHEEL ACK
------------------------------

function state.wheelAckState()
    
    if sosDetection(TARGET) == true then
        robot.leds.set_single_color(13, "blue")
        nextState = "wheelSpState"
        
    else
        nextState = "wheelAckState"
    end
end

------------------------------
-- STATE: WHEEL SP
------------------------------

function state.wheelSpState()
			checkRed = false	     

		  if timer == 0 then
				myColor = randomColor()
            robot.leds.set_single_color(13, myColor)  
		  end 	  
		  
        timer = timer +1
        if timer > TAU then
           -- myColor = randomColor()
           -- robot.leds.set_single_color(13, myColor)                  
            if getTargetColor(TARGET) == myColor then
            	nextState = "wheelSpState"
            --elseif getTargetColor(TARGET) == "red" then
           -- 	nextState = "wheelCeState"
      	   else
            	robot.leds.set_single_color(13, "black")
					nextState = "wheelDeadState"
            end
							
				timer = 0
				checkRed = true
        end                
       if checkRed == true then 
		    if getTargetColor(TARGET) == "red" then
            	nextState = "wheelCeState"
			 end
		 end
end


------------------------------
-- STATE: WHEEL CE
------------------------------

function state.wheelCeState()
    robot.leds.set_single_color(13, "red")
    nextState = "wheelCeState"
end

------------------------------
-- STATE: DEAD
------------------------------

function state.wheelDeadState()
    nextState = "wheelDeadState"
end



-------------------------------------------------
--  GENERAL FUNCTIONS
-------------------------------------------------
function sosDetection(target)
     for i = 1, #robot.colored_blob_omnidirectional_camera do
         if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") then 
             TARGET = {distance = robot.colored_blob_omnidirectional_camera[i].distance, angle = robot.colored_blob_omnidirectional_camera[i].angle}
             return true
         end
    end
    
return false
            
end

--------------------------
-- RESET TIMER           
--------------------------
function resetTimer()
    timer = 0
end


-------------------------------------------------
--  UTILITY FUNCTIONS
-------------------------------------------------

--------------------------
-- ROBOT ID             --
--------------------------
function idNumber()
    robotId = string.gsub(robot.id, "fb", "")
    id = tonumber(robotId)

    return id   
end

--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function colorFieldForce(color, k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if(getColor(robot.colored_blob_omnidirectional_camera[i]) == color) then
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
        end
    end

    return colorForce
end


-------------------------------------------
-- TARGET SELECTION
-------------------------------------------
function targetSelection()
	 target = {distance = 0, angle = 0}
    if #robot.colored_blob_omnidirectional_camera ~= 0 then
        targetIndex = robot.random.uniform_int(1, #robot.colored_blob_omnidirectional_camera +1)
        target = {distance = robot.colored_blob_omnidirectional_camera[targetIndex].distance, angle = robot.colored_blob_omnidirectional_camera[targetIndex].angle}
    end
    
    return target
end

-------------------------------------------
-- GET TARGET COLOR
-------------------------------------------

function getTargetColor(target)
    epsilonD = 0.5
    epsilonA = 0.3
    for i = 1, #robot.colored_blob_omnidirectional_camera do
       dist = robot.colored_blob_omnidirectional_camera[i].distance
       angle = robot.colored_blob_omnidirectional_camera[i].angle
       
       if math.abs(dist - target.distance) < epsilonD and (math.abs(angle - target.angle) < epsilonA) then
            return getColor(robot.colored_blob_omnidirectional_camera[i])
       end
    end
    
    return "white"
end

-------------------------------------------
-- RANDOM COLOR
-------------------------------------------

function randomColor()
    rnd = robot.random.uniform_int(1,3)
    if rnd == 1 then
        return "blue"
    else 
        return "green"
    end
end


----------------------------------------------------------
-- SENSOR COLOR: get  color more safely                 --
----------------------------------------------------------
function getColor(sensor)
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "white"
    end
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 0) then
        return "red"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "green"
    end
    if(sensor.color.red == 0 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "blue"
    end
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "yellow"
    end 
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "purple"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "cyano"
    end
    if(sensor.color.red == 160 and sensor.color.green == 32 and sensor.color.blue == 240) then
        return "darkPurple"
    end
end


--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function fieldForce(k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
    end

    return colorForce
end


------------------------------
-- ANGLE ORIENTATION 
------------------------------
function getAngle()
    PI=math.pi
    angle = robot.positioning.orientation.angle*robot.positioning.orientation.axis.z
   if angle<-PI then angle = angle+2*PI end
   if angle >PI then angle = angle-2*PI end
   return angle
end

------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
if(robot.id == "fb1") then
    if(debugMode == true) then
        log(string)
    end
end
end

------------------------------
-- SPEED FROM FORCE     
------------------------------

function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 0.3

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

--------------------------------
-- VECTOR SUM FORCES    
--------------------------------

function sumUp(forces)
    sumForce = { x=0, y=0}
    for i = 1, #forces do
        sumForce.x = sumForce.x + forces[i].x
        sumForce.y = sumForce.y + forces[i].y
    end
    return sumForce
end

-------------------------------
-- RANDOM FORCE              
-------------------------------

function randomForce(val)
    angle = robot.random.uniform(- math.pi/2, math.pi/2)
   rndForce = {x = val * math.cos(angle), y = val * math.sin(angle) }

    return rndForce
end

-------------------------------
-- neighbourForce             
-------------------------------

function neighbourForce(val, angle)
     force = {x = val * math.cos(angle), y = val * math.sin(angle) }
     return force
end

-------------------------------
-- LINEAR FORCE 
-------------------------------

function linearForce(k)
     if(k == nil) then
        k=10
     end
    lForce = { x=k, y=0}
    return lForce
end

-------------------------------
-- OBSTACLE AVOIDANCE
-------------------------------


function obstacleAvoidanceForce(k,d)
    if(k == nil) then
        k=20
    end
    if(d == nil) then
        d=0.6
     end
   avoidanceForce = {x = 0, y = 0}
   for i = 1,24 do
        -- "-100" for a strong repulsion 
        v = -k * robot.proximity[i].value 
        a = robot.proximity[i].angle 

        sensorForce = {x = v * math.cos(a), y = 2 * v * math.sin(a)}
        avoidanceForce.x = avoidanceForce.x + sensorForce.x
        avoidanceForce.y = avoidanceForce.y + sensorForce.y
   end

    return avoidanceForce
end




--print into Log a table
function tprint (tbl)
  for k, v in pairs(tbl) do
    if type(v) == "table" then
      tprint(v)
    elseif type(v) == 'boolean' then
      myLog(tostring(v))      
    else
      myLog(v)
    end
  end
end