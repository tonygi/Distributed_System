-- Global variables here
state = {}
debugMode = true
nStep = 0
Trandom = 0


function init()
     Trandom = robot.random.uniform_int(1, 100)
    nextState = "initState"
    robot.colored_blob_omnidirectional_camera.enable()
end


function step()
    nStep = nStep + 1
    state[nextState]()
end


function reset()
    nextState = "initState"
    --robot.colored_blob_omnidirectional_camera.enable()
end

function destroy()
   -- destroy
end






------------------------------
-- STATE: Init
------------------------------

function state.initState()
    robot.leds.set_single_color(13, "green")
    resetTime()
    if detectLeader() == true then
        nextState="slaveState"
    elseif Trandom == 0 then
		  
        nextState="leaderState"
    else
        Trandom = Trandom - 1
        nextState="initState"
    end

    
end



------------------------------
-- STATE: Leader
------------------------------
function state.leaderState()

    robot.leds.set_single_color(13, "red")

    if detectLeader() == true then
        nextState="initState"
    else
        nextState="leaderState"
    end
    
end

------------------------------
-- STATE: Slave
------------------------------

function state.slaveState()
    robot.leds.set_single_color(13, "blue")
    if detectLeader() == true then
        nextState="slaveState"
    else
        nextState="initState"
    end 
end




-------------------------------------------------
--  GENERAL FUNCTIONS
-------------------------------------------------

function detectLeader()--red is leader
    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") then
			  if(robot.colored_blob_omnidirectional_camera[i].distance < 180) then
              return true
			  end
        end
    end
    return false
end

function resetTime()
     Trandom = robot.random.uniform_int(0, 100)
end


function angOfColorCluster(color)

arrayAng = { 0,  0,  0,  0}
arraySumAng = { {x=0, y=0}, {x=0, y=0}, {x=0, y=0}, {x=0, y=0}}
PI = math.pi
for i = 1, #robot.colored_blob_omnidirectional_camera do    
    if(getColor(robot.colored_blob_omnidirectional_camera[i]) == color) then
    angle = robot.colored_blob_omnidirectional_camera[i].angle
    val   = robot.colored_blob_omnidirectional_camera[i].distance
    force = {x = val * math.cos(angle), y = val * math.sin(angle) }
        if      angle <= -PI / 2 then
            arrayAng[1] = arrayAng[1] + 1   
            arraySumAng[1] = sumUp({arraySumAng[1], force})
        elseif  angle <= 0 and angle > -PI / 2 then
            arrayAng[2] =  arrayAng[2] + 1
            arraySumAng[2] = sumUp({arraySumAng[2], force})

        elseif angle <= PI/2 and angle > 0 then
            arrayAng[3] =  arrayAng[3] + 1
            arraySumAng[3] = sumUp({arraySumAng[3], force})
        else 
            arrayAng[4] = arrayAng[4] + 1
            arraySumAng[4] = sumUp({arraySumAng[4], force})
        end
    end    
end

maxIndex = 1     
max = arrayAng[1]
for i=2, #arrayAng do 
    if arrayAng[i] > max then
       max = arrayAng[i]
       maxIndex = i 
    end    
end
    
return arraySumAng[maxIndex]

end 


function countRobot()
 N = 0
 threshold = 60
 
 for i = 1, #robot.colored_blob_omnidirectional_camera do
    val   = robot.colored_blob_omnidirectional_camera[i].distance
    if val < threshold then
        N = N +1
    end
end

return N

end 

function probStop()
N    = countRobot()
alfa = 0.4
S    = robot.random.uniform()
Ps   = math.min(1, S + alfa*N)
return Ps
end

function probWander()
N    = countRobot()
beta = 0.4
W    = robot.random.uniform()
Pw   = math.max(0, W - beta*N)
return Pw
end
--------------------------
--  MIN DISTANCE COLOR  --
--------------------------
function minDistance()
    minDist = math.huge
    minAngle = 0

    for i = 1, #robot.colored_blob_omnidirectional_camera do
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle
            if (dist<minDist)then
                minDist = dist
                minAngle = angle
            end
    end
    
    mdc = { dist = minDist, angle = minAngle}

    return mdc
end

-------------------------------------------------
--  UTILITY FUNCTIONS
-------------------------------------------------

--------------------------
-- ROBOT ID             --
--------------------------
function idNumber()
    robotId = string.gsub(robot.id, "fb", "")
    id = tonumber(robotId)

    return id   
end

--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function colorFieldForce(color, k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if(getColor(robot.colored_blob_omnidirectional_camera[i]) == color) then
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
        end
    end

    return colorForce
end

----------------------------------------------------------
-- SENSOR COLOR: get  color more safely                 --
----------------------------------------------------------
function getColor(sensor)
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "white"
    end
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 0) then
        return "red"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "green"
    end
    if(sensor.color.red == 0 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "blue"
    end
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "yellow"
    end 
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "purple"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "cyano"
    end
    if(sensor.color.red == 160 and sensor.color.green == 32 and sensor.color.blue == 240) then
        return "darkPurple"
    end
end


--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function fieldForce(k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
    end

    return colorForce
end


------------------------------
-- ANGLE ORIENTATION 
------------------------------
function getAngle()
    PI=math.pi
    angle = robot.positioning.orientation.angle*robot.positioning.orientation.axis.z
   if angle<-PI then angle = angle+2*PI end
   if angle >PI then angle = angle-2*PI end
   return angle
end

------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
if(robot.id == "fb1") then
    if(debugMode == true) then
        log(string)
    end
end
end

------------------------------
-- SPEED FROM FORCE     
------------------------------

function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 0.3

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

--------------------------------
-- VECTOR SUM FORCES    
--------------------------------

function sumUp(forces)
    sumForce = { x=0, y=0}
    for i = 1, #forces do
        sumForce.x = sumForce.x + forces[i].x
        sumForce.y = sumForce.y + forces[i].y
    end
    return sumForce
end

-------------------------------
-- RANDOM FORCE              
-------------------------------

function randomForce(val)
    angle = robot.random.uniform(- math.pi/2, math.pi/2)
   rndForce = {x = val * math.cos(angle), y = val * math.sin(angle) }

    return rndForce
end

-------------------------------
-- neighbourForce             
-------------------------------

function neighbourForce(val, angle)
     force = {x = val * math.cos(angle), y = val * math.sin(angle) }
     return force
end

-------------------------------
-- LINEAR FORCE 
-------------------------------

function linearForce(k)
     if(k == nil) then
        k=10
     end
    lForce = { x=k, y=0}
    return lForce
end

-------------------------------
-- OBSTACLE AVOIDANCE
-------------------------------


function obstacleAvoidanceForce(k,d)
    if(k == nil) then
        k=20
    end
    if(d == nil) then
        d=0.6
     end
   avoidanceForce = {x = 0, y = 0}
   for i = 1,24 do
        -- "-100" for a strong repulsion 
        v = -k * robot.proximity[i].value 
        a = robot.proximity[i].angle 

        sensorForce = {x = v * math.cos(a), y = 2 * v * math.sin(a)}
        avoidanceForce.x = avoidanceForce.x + sensorForce.x
        avoidanceForce.y = avoidanceForce.y + sensorForce.y
   end

    return avoidanceForce
end




--print into Log a table
function tprint (tbl)
  for k, v in pairs(tbl) do
    if type(v) == "table" then
      tprint(v)
    elseif type(v) == 'boolean' then
      myLog(tostring(v))      
    else
      myLog(v)
    end
  end
end

