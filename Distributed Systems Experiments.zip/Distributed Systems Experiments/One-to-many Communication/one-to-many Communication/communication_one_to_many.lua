-- Global variables here
state = {}
debugMode = true
nStep = 0
Trandom = 0
TARGET = {}
timer = 0
timerCan = 0
timerCnn = 0
TAU = 25
TAUCanCnn= 60
myColor = ""
addTimer=0
addThreshold = 80
DESIRED_GROUP = 6

function init()
    
    nextState = "wheelAckState"
   
    robot.colored_blob_omnidirectional_camera.enable()
    if robot.id == "fb0" then
        nextState = "sosState"
    end

end


function step()
    nStep = nStep + 1
    state[nextState]()
end


function reset()
   
    nextState = "wheelAckState"
    if robot.id == "fb0" then
        nextState = "sosState"
    end
end

function destroy()
   -- destroy
end

------------------------------
-- STATE: deadState  
------------------------------
function state.deadState()
   robot.leds.set_single_color(13, "blue")
		--robot.leds.set_single_color(13, "black")
end
------------------------------
-- STATE: sta  (Stable Group Size)
------------------------------

function state.staState() 
    robot.leds.set_single_color(13, "red")

    if numberRedRobots() < DESIRED_GROUP and nStep % 10 == 0 then
		 robot.leds.set_single_color(13, "green")
       nextState = "addState"  
	 end
    if numberRedRobots() == DESIRED_GROUP then
    	 robot.leds.set_single_color(13, "blue")
       nextState = "deadState"  
    end
end


------------------------------
-- STATE: add   (Add Members)
------------------------------

function state.addState()   
   robot.leds.set_single_color(13, "green")
   
   if numberRedAndGreenRobots() > DESIRED_GROUP then
		robot.leds.set_single_color(13, "blue")
   		nextState = "leaState"
   		return 
   end      
   if numberRedAndGreenRobots() <= DESIRED_GROUP and nStep % 60 == 0 then
		--addTimer = addTimer + 1
	--end
	
	--if addTimer > addThreshold then
    --   if robot.random.bernoulli() then
		-- 	 robot.leds.set_single_color(13, "red")
       	 nextState = "staState"
	 --   end
   else
       nextState = "addState"
   end
   
end


------------------------------
-- STATE: lea
------------------------------

function state.leaState()
    robot.leds.set_single_color(13, "blue")
     if numberRedAndGreenRobots() <= DESIRED_GROUP then
			robot.leds.set_single_color(13, "red")
        nextState = "staState"
     else
        nextState = "leaState"
     end
    
end


------------------------------
-- STATE: hib (hibernate)
------------------------------

function state.hibState()
    robot.leds.set_single_color(13, "black")
    targetColor = getTargetColor(TARGET)
   
    if (targetColor == "green")  and (checkRed() == true) and (adjacent() == true) and (checkLeaderOnlyGreen()==true) then 
		  robot.leds.set_single_color(13, "blue") 
        nextState = "canState"
    else  
        nextState = "hibState"
    end
end

------------------------------
-- STATE: can (candidate)
------------------------------

function state.canState()
    robot.leds.set_single_color(13, "blue")
 
    if adjacent() == false then
    	robot.leds.set_single_color(13, "black")
      nextState = "hibState"
      return
    end

    timerCan = timerCan +1 
    
    if  timerCan > TAUCanCnn then 
            
       if robot.random.bernoulli() == 1 then --se e' vera va in cnn, se false in hib
           robot.leds.set_single_color(13, "green")
           nextState = "cnnState"
       else
          robot.leds.set_single_color(13, "black")
          nextState = "hibState" 
       end
		 timerCan = 0
    else
        nextState = "canState"
    end
    
end


------------------------------
-- STATE: cnn (closest candidate)
------------------------------

function state.cnnState()
    robot.leds.set_single_color(13, "green")
    targetColor = getTargetColor(TARGET)

	nextState = "cnnState"

    if targetColor == "red" then 
		  robot.leds.set_single_color(13, "red")
        nextState = "memState"
		  return 
    end

    if targetColor == "blue" then
        timerCnn = timerCnn + 1 
    end
    
    if timerCnn > TAUCanCnn then
        if robot.random.bernoulli(0.5) == 1 then
			  robot.leds.set_single_color(13, "black")
           nextState = "hibState"
        else
           timerCnn = 0
        end
    end
end

------------------------------
-- STATE: MEM
------------------------------

function state.memState()
   robot.leds.set_single_color(13, "red")
end

-------------------------------------------------
-- ONE-TO-ONE COMMUNICATION STATES
-------------------------------------------------

------------------------------
-- STATE: SOS
------------------------------
function state.sosState()
    robot.leds.set_single_color(13, "red")
    TARGET = targetSelection()
    if getTargetColor(TARGET) == "blue" then
        nextState = "spState"
    else
        nextState = "sosState"
    end
end



------------------------------
-- STATE: SP
------------------------------
function state.spState()
    targetColor = getTargetColor(TARGET)
    if targetColor ~= "white" then 
        robot.leds.set_single_color(13, targetColor)
    
     if  #robot.colored_blob_omnidirectional_camera == 1 then
		  robot.leds.set_single_color(13, "red")
        nextState = "ceState"
     else
        nextState = "spState"
     end
    
     else
        nextState = "sosState"
     end
end


------------------------------
-- STATE: CE
------------------------------

function state.ceState()
    robot.leds.set_single_color(13, "red")
    targetColor = getTargetColor(TARGET)
    if targetColor == "red" then 
    	nextState = "staState"     
    else
      nextState = "ceState"
    end
end



------------------------------
-- STATE: WHEEL ACK
------------------------------
function state.wheelAckState()
	robot.leds.set_single_color(13, "black")
    if sosDetection(TARGET) == true then
        robot.leds.set_single_color(13, "blue")
        nextState = "wheelSpState"        
    else
        nextState = "wheelAckState"
    end
end

------------------------------
-- STATE: WHEEL SP
------------------------------

function state.wheelSpState()
                

        if timer == 0 then
        	myColor = randomColor()
         	robot.leds.set_single_color(13, myColor)  
        end     
          
        timer = timer +1

        if timer > TAU then
                          
           if getTargetColor(TARGET) == myColor then
                nextState = "wheelSpState"
           elseif getTargetColor(TARGET) == "red" then
					robot.leds.set_single_color(13, "red")
					--nextState = "wheelCeState"
					nextState = "memState"

			  else
                robot.leds.set_single_color(13, "black")
                nextState = "partialDeadState"
           end
                            
           timer = 0
        end   
             
end


------------------------------
-- STATE: WHEEL CE
------------------------------

function state.wheelCeState()
    robot.leds.set_single_color(13, "red")
    targetColor = getTargetColor(TARGET)
    
    if targetColor == "red" then 
         nextState = "memState"     
     else
         nextState = "wheelCeState"
     end
end


------------------------------
-- STATE: PARTIAL DEAD
------------------------------

function state.partialDeadState()
    robot.leds.set_single_color(13, "black")
     targetColor = getTargetColor(TARGET)
    
    if targetColor == "red" then 
         nextState = "hibState"     
     else
         nextState = "partialDeadState"
     end
end

-------------------------------------------------
--  GENERAL FUNCTIONS
-------------------------------------------------
--------------------------
--  MIN DISTANCE COLOR  --
--------------------------
function minDistanceColor(color)
    minDist =9999
    minAngle = 0

    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if ( getColor(robot.colored_blob_omnidirectional_camera[i])==color) then
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle
            if (dist<minDist)then
                minDist = dist
                minAngle = angle
            end
        end
    end
    
    mdc = { dist = minDist, angle = minAngle}

    return mdc
end

----------------------------
--FUNCTION ONE-TO-MANY
----------------------------
function numberRedRobots()
    count = 0
    for i = 1, #robot.colored_blob_omnidirectional_camera do
         if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") then
             count = count + 1
         end
    end
    
    return count
end

function numberRedAndGreenRobots()
    count = 0
    for i = 1, #robot.colored_blob_omnidirectional_camera do
         if ((getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") or 
             (getColor(robot.colored_blob_omnidirectional_camera[i]) == "green") )then
             count = count + 1
         end
    end
    
    return count
end

function checkRed()
    for i = 1, #robot.colored_blob_omnidirectional_camera do
       if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") then
          return true
       end
    end

    return false    
end        

function isMinAdiacent()
        
    if #robot.colored_blob_omnidirectional_camera ~= 0 then
        for i = 1, #robot.colored_blob_omnidirectional_camera do
              if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "blue") then
                
                dist = robot.colored_blob_omnidirectional_camera[i].distance
                angle = robot.colored_blob_omnidirectional_camera[i].angle                            
                
                x = TARGET.distance * math.cos(TARGET.angle) - dist * math.cos(angle)
                y = TARGET.distance * math.sin(TARGET.angle) - dist * math.sin(angle)
                
                neighbourDistance = math.sqrt(x*x -y*y)
                
                if neighbourDistance < TARGET.distance then
                    return true
                end
                
              end
        end
    end
    
    return false    
end


function isMinAdiacent2(nearestRed)
    if #robot.colored_blob_omnidirectional_camera ~= 0 and nearestRed ~= nil then
        for i = 1, #robot.colored_blob_omnidirectional_camera do
        dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle                            
              if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "blue" 
and ( angle > (nearestRed.angle - math.pi/5.0) and angle < (nearestRed.angle + math.pi/5.0))
) then        
                 -- myLog("angle1: "..angle)                     
             -- myLog("angle2: "..nearestRed.angle - 3.0/8.0*math.pi)
              --  x = nearestRed.distance * math.cos(nearestRed.angle) - dist * math.cos(angle)
               -- y = nearestRed.distance * math.sin(nearestRed.angle) - dist * math.sin(angle)
                
               -- neighbourDistance = math.sqrt(x*x -y*y)
                
                --if neighbourDistance < nearestRed.distance then
                     if dist < nearestRed.distance then
                    return true
                end
                
              end
        end
    end
    
    return false    
end



-------------------------------------------
-- IS ADJACENT
-------------------------------------------
function adjacent()
    nearestRed = minDistanceColor("red")
    
    if nearestRed.dist == 9999 then
        return false
    end
    
    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if ( getColor(robot.colored_blob_omnidirectional_camera[i])== "blue") then
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle
            if  (nearestRed.angle - math.pi/5.0 < angle) and angle < (nearestRed.angle + math.pi/5.0) then
                if dist < nearestRed.dist then
                    return false
                end
            end
        end
    end
    
    return true
end

function checkLeaderOnlyGreen()
    count = 0
    if #robot.colored_blob_omnidirectional_camera ~= 0 then
        for i = 1, #robot.colored_blob_omnidirectional_camera do            
            if getColor(robot.colored_blob_omnidirectional_camera[i]) == "green"  then
                count = count + 1
            end
            if count > 1 then return false end
        end
        --return true
    end
    return true
end

function closestGroupMember()
    if #robot.colored_blob_omnidirectional_camera ~= 0 then
        minDistance = math.huge
        minAngle = 0
      for i = 1, #robot.colored_blob_omnidirectional_camera do  
           distance = robot.colored_blob_omnidirectional_camera[i].distance          
            if ((getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") and (distance < minDistance)) then
                 minDistance = distance
                 minAngle = robot.colored_blob_omnidirectional_camera[i].angle
             end
        end
        closest_group_member = { distance = minDistance, angle = minAngle }
        return closest_group_member
    end 
    return nil
end

----------------------------
--FUNCTION ONE-TO-ONE
---------------------------

function sosDetection(target)
     for i = 1, #robot.colored_blob_omnidirectional_camera do
         if(getColor(robot.colored_blob_omnidirectional_camera[i]) == "red") then 
             TARGET = {distance = robot.colored_blob_omnidirectional_camera[i].distance, angle = robot.colored_blob_omnidirectional_camera[i].angle}
             return true
         end
    end
return false     
end

--------------------------
-- RESET TIMER           
--------------------------
function resetTimer()
    timer = 0
end






-------------------------------------------------
--  UTILITY FUNCTIONS
-------------------------------------------------

--------------------------
-- ROBOT ID             --
--------------------------
function idNumber()
    robotId = string.gsub(robot.id, "fb", "")
    id = tonumber(robotId)

    return id   
end

--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function colorFieldForce(color, k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
        if(getColor(robot.colored_blob_omnidirectional_camera[i]) == color) then
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
        end
    end

    return colorForce
end


-------------------------------------------
-- TARGET SELECTION
-------------------------------------------
function targetSelection()
     target = {distance = 0, angle = 0}
    if #robot.colored_blob_omnidirectional_camera ~= 0 then
        targetIndex = robot.random.uniform_int(1, #robot.colored_blob_omnidirectional_camera +1)
        target = {distance = robot.colored_blob_omnidirectional_camera[targetIndex].distance, angle = robot.colored_blob_omnidirectional_camera[targetIndex].angle}
    end
    
    return target
end

-------------------------------------------
-- GET TARGET COLOR
-------------------------------------------

function getTargetColor(target)
    epsilonD = 0.5
    epsilonA = 0.3
    for i = 1, #robot.colored_blob_omnidirectional_camera do
       dist = robot.colored_blob_omnidirectional_camera[i].distance
       angle = robot.colored_blob_omnidirectional_camera[i].angle
       
       if math.abs(dist - target.distance) < epsilonD and (math.abs(angle - target.angle) < epsilonA) then
            return getColor(robot.colored_blob_omnidirectional_camera[i])
       end
    end
    
    return "white"
end

-------------------------------------------
-- RANDOM COLOR
-------------------------------------------

function randomColor()
    rnd = robot.random.uniform_int(1,3)
    if rnd == 1 then
        return "blue"
    else 
        return "green"
    end
end


----------------------------------------------------------
-- SENSOR COLOR: get  color more safely                 --
----------------------------------------------------------
function getColor(sensor)
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "white"
    end
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 0) then
        return "red"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "green"
    end
    if(sensor.color.red == 0 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "blue"
    end
    if(sensor.color.red == 255 and sensor.color.green == 255 and sensor.color.blue == 0) then
        return "yellow"
    end 
    if(sensor.color.red == 255 and sensor.color.green == 0 and sensor.color.blue == 255) then
        return "purple"
    end
    if(sensor.color.red == 0 and sensor.color.green == 255 and sensor.color.blue == 255) then
        return "cyano"
    end
    if(sensor.color.red == 160 and sensor.color.green == 32 and sensor.color.blue == 240) then
        return "darkPurple"
    end
end


--------------------------
-- COLOR FIELD FORCE    --
--------------------------

function fieldForce(k, a)
    if(a==nil)then
        a=1
    end

    colorForce = {x = 0, y = 0}

    for i = 1, #robot.colored_blob_omnidirectional_camera do
            dist = robot.colored_blob_omnidirectional_camera[i].distance
            angle = robot.colored_blob_omnidirectional_camera[i].angle

            colorForce.x = colorForce.x + k/dist * math.cos(angle)
            colorForce.y = colorForce.y + k*a/dist * math.sin(angle)
    end

    return colorForce
end


------------------------------
-- ANGLE ORIENTATION 
------------------------------
function getAngle()
    PI=math.pi
    angle = robot.positioning.orientation.angle*robot.positioning.orientation.axis.z
   if angle<-PI then angle = angle+2*PI end
   if angle >PI then angle = angle-2*PI end
   return angle
end

------------------------------
-- LOG FUNCTION 
------------------------------
function myLog(string)
    if(debugMode == true) then
        log(string)
    end
end

------------------------------
-- SPEED FROM FORCE     
------------------------------

function speedFromForce(f)
    forwardSpeed = f.x * 1.0
    angularSpeed = f.y * 0.3

    leftSpeed  = forwardSpeed - angularSpeed
    rightSpeed = forwardSpeed + angularSpeed

    robot.wheels.set_velocity(leftSpeed,rightSpeed)
end

--------------------------------
-- VECTOR SUM FORCES    
--------------------------------

function sumUp(forces)
    sumForce = { x=0, y=0}
    for i = 1, #forces do
        sumForce.x = sumForce.x + forces[i].x
        sumForce.y = sumForce.y + forces[i].y
    end
    return sumForce
end

-------------------------------
-- RANDOM FORCE              
-------------------------------

function randomForce(val)
    angle = robot.random.uniform(- math.pi/2, math.pi/2)
   rndForce = {x = val * math.cos(angle), y = val * math.sin(angle) }

    return rndForce
end

-------------------------------
-- neighbourForce             
-------------------------------

function neighbourForce(val, angle)
     force = {x = val * math.cos(angle), y = val * math.sin(angle) }
     return force
end

-------------------------------
-- LINEAR FORCE 
-------------------------------

function linearForce(k)
     if(k == nil) then
        k=10
     end
    lForce = { x=k, y=0}
    return lForce
end

-------------------------------
-- OBSTACLE AVOIDANCE
-------------------------------


function obstacleAvoidanceForce(k,d)
    if(k == nil) then
        k=20
    end
    if(d == nil) then
        d=0.6
     end
   avoidanceForce = {x = 0, y = 0}
   for i = 1,24 do
        -- "-100" for a strong repulsion 
        v = -k * robot.proximity[i].value 
        a = robot.proximity[i].angle 

        sensorForce = {x = v * math.cos(a), y = 2 * v * math.sin(a)}
        avoidanceForce.x = avoidanceForce.x + sensorForce.x
        avoidanceForce.y = avoidanceForce.y + sensorForce.y
   end

    return avoidanceForce
end




--print into Log a table
function tprint (tbl)
  for k, v in pairs(tbl) do
    if type(v) == "table" then
      tprint(v)
    elseif type(v) == 'boolean' then
      myLog(tostring(v))      
    else
      myLog(v)
    end
  end
end
